//
//  main.c
//  cxl001
//
//  Created by chenxiaolong on 15/10/6.
//  Copyright (c) 2015年 chenxiaolong. All rights reserved.
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
    // insert code here...
    printf("Hello,Xiaolong's MAC OS!\n");
    return 0;
}
