//
//  main.m
//  cxl002
//
//  Created by chenxiaolong on 15/10/7.
//  Copyright (c) 2015年 chenxiaolong. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
        int choice=34;
        //int choice=37;
        
        char a='a';
        char b='b';
        a=a-32;
        b=b-32;
        NSLog(@"%c,%c",a,b);
        NSLog(@"%i,%i",a,b);
        NSLog(@"Hello, cxl objective C!");
        //exp_3.4
        
        
        switch(choice)
        {
            case 34:
                NSLog(@"我是例3-4,switch实例。");
                break;
            case 35:
                NSLog(@"我是例3-5");
                break;
            default:
                NSLog(@"我是其它例");
                break;
        }
    }
    return 0;
}
