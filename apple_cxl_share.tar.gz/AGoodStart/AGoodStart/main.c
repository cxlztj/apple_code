//
//  main.c
//  AGoodStart
//
//  Created by cxl on 15-10-4.
//  Copyright (c) 2015年 com.cxl. All rights reserved.
//

#include <stdio.h>

int main(int argc, const char * argv[])
{

    // insert code here...
    printf("Hello, World!\n");
    return 0;
}

