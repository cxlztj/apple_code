//
//  FreeTar
//  PreferencesController.m
//
//  Copyright (c) 2002 Murray M Johnson
//
//	http://homepage.mac.com/mjsoftware/
//	mjsoftware@mac.com
//
//
//  This file is part of FreeTar version 1.1.
//
//  FreeTar is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  FreeTar is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with FreeTar; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

#import "PreferencesController.h"
#import "FreeTarPreferences.h"


// control related constants
#define PATH_GNUTAR_TAG			0
#define PATH_TAR_TAG			1
#define PATH_CUSTOM_TAG			2


NSString*	GNUTAR_PATH			= @"/usr/bin/gnutar";
NSString*	TAR_PATH			= @"/usr/bin/tar";

#define	COMP_GZIP_TAG			0
#define	COMP_COMPRESS_TAG		1
#define	COMP_BZIP_TAG	        	2
#define	COMP_NONE_TAG			3

#define	LOC_AUTO_TAG			0
#define	LOC_USER_TAG			1

#define	EXT_SHORT_TAG			0
#define	EXT_LONG_TAG			1
#define	EXT_CUSTOM_TAG			2

NSString*	GZIP_SHORT_EXT		= @"tgz";
NSString*	GZIP_LONG_EXT		= @"tar.gz";
NSString*	COMPRESS_SHORT_EXT	= @"taz";
NSString*	COMPRESS_LONG_EXT	= @"tar.Z";
NSString*	BZIP_SHORT_EXT	        = @"tz2";
NSString*	BZIP_LONG_EXT	        = @"tar.bz2";
NSString*	NONE_SHORT_EXT		= @"tar";

#define	MULT_SINGLE_TAG			0
#define	MULT_MULTIPLE_TAG		1


@implementation PreferencesController


- (id) initWithPrefsObject:(FreeTarPreferences*)inPrefs
{
  self = [super initWithWindowNibName:@"Preferences.gorm"];
  prefsObj = inPrefs;
  return self;
}


// inherited from NSWindowController. Like "awakeFromNib", inititialize UI elements
- (void) windowDidLoad
{
  //DBG
  NSLog(@"windowDidLoad");

	
  // set window delegate
  [[self window] setDelegate:self];
	

  // set-up controls
  [tarPathText setStringValue:[prefsObj launchPath]];
  [self syncTarPath];
	
  if([prefsObj compressWithGzip])
    {
      [compressRadio selectCellWithTag:COMP_GZIP_TAG];
      [[extensionRadio cellWithTag:EXT_LONG_TAG] setEnabled:YES];
    }
  else if([prefsObj compressWithCompress])
    {
      [compressRadio selectCellWithTag:COMP_COMPRESS_TAG];
      [[extensionRadio cellWithTag:EXT_LONG_TAG] setEnabled:YES];
    }
  else if([prefsObj compressWithBzip])
    {
      [compressRadio selectCellWithTag:COMP_BZIP_TAG];
      [[extensionRadio cellWithTag:EXT_LONG_TAG] setEnabled:YES];
    }
  else
    {
      [compressRadio selectCellWithTag:COMP_NONE_TAG];
      [[extensionRadio cellWithTag:EXT_LONG_TAG] setEnabled:NO];
    }

  [extensionText setStringValue:[prefsObj archiveExtension]];
  [self syncExtension];

  if([prefsObj autoLocation])
    {
      [locationRadio selectCellWithTag:LOC_AUTO_TAG];
    }
  else
    {
      [locationRadio selectCellWithTag:LOC_USER_TAG];
    }


  if([prefsObj multipleArchives])
    {
      [multArchivesRadio selectCellWithTag:MULT_MULTIPLE_TAG];
    }
  else
    {
      [multArchivesRadio selectCellWithTag:MULT_SINGLE_TAG];
    }

  //TODO: display autoBaseDir pref
}


- (IBAction)compressRadioAction:(id)sender
{
  // set prefs
  switch([[compressRadio selectedCell] tag])
    {
    case COMP_GZIP_TAG:
      [prefsObj setCompressWithGzip:YES];
      [prefsObj setCompressWithCompress:NO];
      [prefsObj setCompressWithBzip:NO];
      [[extensionRadio cellWithTag:EXT_LONG_TAG] setEnabled:YES];
      break;

    case COMP_COMPRESS_TAG:
      [prefsObj setCompressWithGzip:NO];
      [prefsObj setCompressWithCompress:YES];
      [prefsObj setCompressWithBzip:NO];
      [[extensionRadio cellWithTag:EXT_LONG_TAG] setEnabled:YES];
      break;

    case COMP_BZIP_TAG:
      [prefsObj setCompressWithGzip:NO];
      [prefsObj setCompressWithCompress:NO];
      [prefsObj setCompressWithBzip:YES];
      [[extensionRadio cellWithTag:EXT_LONG_TAG] setEnabled:YES];
      break;


    case COMP_NONE_TAG:
      [prefsObj setCompressWithGzip:NO];
      [prefsObj setCompressWithCompress:NO];
      [prefsObj setCompressWithBzip:NO];
      [[extensionRadio cellWithTag:EXT_LONG_TAG] setEnabled:NO];
      if([[extensionRadio selectedCell] tag] == EXT_LONG_TAG)
	[extensionRadio selectCellWithTag:EXT_SHORT_TAG];
      break;

    }

  // update extension
  [self extensionRadioAction:nil];
}


- (IBAction)extensionRadioAction:(id)sender
{
  // set text box value
  switch([[extensionRadio selectedCell] tag])
    {
    case EXT_SHORT_TAG:
      if([prefsObj compressWithGzip])
	[extensionText setStringValue:GZIP_SHORT_EXT];
      else if([prefsObj compressWithCompress])
	[extensionText setStringValue:COMPRESS_SHORT_EXT];
      else if([prefsObj compressWithBzip])
	[extensionText setStringValue:BZIP_SHORT_EXT];
      else
	[extensionText setStringValue:NONE_SHORT_EXT];
      break;

    case EXT_LONG_TAG:
      if([prefsObj compressWithGzip])
	[extensionText setStringValue:GZIP_LONG_EXT];
      else if([prefsObj compressWithCompress])
	[extensionText setStringValue:COMPRESS_LONG_EXT];
      else if([prefsObj compressWithBzip])
	[extensionText setStringValue:BZIP_LONG_EXT];

      break;

    case EXT_CUSTOM_TAG:
      // don't change the text box value
      break;
    }

  [prefsObj setArchiveExtension:[extensionText stringValue]];
}


- (IBAction)locationRadioAction:(id)sender
{
  // set prefs
  switch([[locationRadio selectedCell] tag])
    {
    case LOC_AUTO_TAG:
      [prefsObj setAutoLocation:YES];
      break;

    case LOC_USER_TAG:
      [prefsObj setAutoLocation:NO];
      break;
    }
}


- (IBAction)revertToDfltsButton:(id)sender
{
  [prefsObj setLaunchPath:@"/usr/bin/tar"];
  [prefsObj setCompressWithGzip:YES];
  [prefsObj setCompressWithCompress:NO];
  [prefsObj setArchiveExtension:@"tgz"];
  [prefsObj setAutoLocation:NO];
  [prefsObj setMultipleArchives:NO];

  // update UI
  [self windowDidLoad];
}


- (IBAction)tarPathRadioAction:(id)sender
{
  // set text box value
  switch([[tarPathRadio selectedCell] tag])
    {
    case PATH_GNUTAR_TAG:
      [tarPathText setStringValue:GNUTAR_PATH];
      break;

    case PATH_TAR_TAG:
      [tarPathText setStringValue:TAR_PATH];
      break;

    case PATH_CUSTOM_TAG:
      // don't change the text box value
      break;
    }
	
  [prefsObj setLaunchPath:[tarPathText stringValue]];
}


- (IBAction)multArchivesRadioAction:(id)sender
{
  switch([[multArchivesRadio selectedCell] tag])
    {
    case MULT_SINGLE_TAG:
      [prefsObj setMultipleArchives:NO];
      break;
			
    case MULT_MULTIPLE_TAG:
      [prefsObj setMultipleArchives:YES];
      break;
    }
}


// NSTextField delegate function
- (void)controlTextDidChange:(NSNotification *)aNotification
{
  if( [aNotification object] ==tarPathText )
    {
      [self syncTarPath];
    }
  else
    {
      [self syncExtension];
      [prefsObj setArchiveExtension:[extensionText stringValue]];
    }
}


// NSTextField delegate function
- (void)controlTextDidEndEditing:(NSNotification *)aNotification
{
  //DBG
  NSLog(@"controlTextDidEndEditing:");
	
  if( [aNotification object]==tarPathText )
    {
      [self errorCheckTarPath];
    }
}


- (void) errorCheckTarPath
{
  NSString*	tar_path;
  int		rtn_val;
  BOOL		is_dir;

  //DBG
  NSLog(@"errorCheckTarPath");

  tar_path = [tarPathText stringValue];
  
  // check length and warn about custom path names
  if([tar_path length] == 0)
    {
      // revert to default
      [tarPathText setStringValue:GNUTAR_PATH];
      [prefsObj setLaunchPath:GNUTAR_PATH];
      [self syncTarPath];
    }
  else if( ![tar_path isEqualToString:GNUTAR_PATH] &&
	   ![tar_path isEqualToString:TAR_PATH] &&
	   ![tar_path isEqualToString:[prefsObj launchPath]] )
    {
      // different panels if file exists or not
      is_dir = NO;
      if(![[NSFileManager defaultManager] fileExistsAtPath:tar_path isDirectory:&is_dir] || is_dir)
	{
#ifdef __APPLE__		   
	  // show alert panel
	  NSBeginCriticalAlertSheet(
				    NSLocalizedString(@"FreeTar Error", @"Error sheet title"),
				    // title
				    nil,					// dflt button -- nil = localized "OK"
				    nil,					// alternate button
				    nil,					// other button
				    [self window],			// window
				    nil,					// modal delagate
				    nil,					// willEndSelector
				    nil,					// didEndSelector
				    nil,					// context info
				    NSLocalizedString(@"Custom path does not exist", nil)
				    // message
				    );

	  // run modal loop
	  rtn_val = [NSApp runModalForWindow:[[self window] attachedSheet]];
#else
	  NSRunAlertPanel ( _(@"Free Tar Error"), 
			    _(@"Custom Path does not Exist"), 
			    _(@"OK"),
			    nil,
			    nil);
#endif		    			
	  // ignore actual return value (there's only one button), set to cancel
	  // button so we'll reset tp the default path
	  [tarPathText setStringValue:GNUTAR_PATH];
	  [prefsObj setLaunchPath:GNUTAR_PATH];
	  [self syncTarPath];
	}
      else
	{
#ifdef __APPLE__
	  // show alert panel
	  NSBeginAlertSheet(
			    NSLocalizedString(@"FreeTar Warning", @"Warning sheet title"),
			    // title
			    nil,					// dflt button -- nil = localized "OK"
			    NSLocalizedString(@"Cancel", @"Cancel button"),
			    // alternate button
			    nil,					// other button
			    [self window],			// window
			    nil,					// modal delagate
			    nil,					// willEndSelector
			    nil,					// didEndSelector
			    nil,					// context info
			    NSLocalizedString(@"Custom path warning", nil)
			    // message
			    );
	  
	  // run modal loop
	  rtn_val = [NSApp runModalForWindow:[[self window] attachedSheet]];

	  
	  // if user presses cancel button set back to default
	  if(rtn_val == NSCancelButton)
	    {
	      [tarPathText setStringValue:GNUTAR_PATH];
	      [prefsObj setLaunchPath:GNUTAR_PATH];
	      [self syncTarPath];
	    }
	  else
	    {
				// set user prefs
	      [prefsObj setLaunchPath:tar_path];
	    }
	  [NSApp endSheet:[[self window] attachedSheet]];
#else
	  rtn_val=NSRunAlertPanel ( _(@"Free Tar Error"), 
				    _(@"Custom Path Warning"), 
				    _(@"Cancel"),
				    nil,
				    nil);
			
	  // if user presses cancel button set back to default
	  if(! rtn_val)
	    {
	      [tarPathText setStringValue:GNUTAR_PATH];
	      [prefsObj setLaunchPath:GNUTAR_PATH];
	      [self syncTarPath];
	    }
	  else
	    {
	      // set user prefs
	      [prefsObj setLaunchPath:tar_path];
	    }

#endif		    			
	  
	  
	  
	}

    }
  else
    {
      // set user prefs
      [prefsObj setLaunchPath:tar_path];
    }
}


- (void) syncTarPath
{
	NSString* ctrl_value = [tarPathText stringValue];

	// check for matches with choices
	if([ctrl_value isEqualToString:GNUTAR_PATH])
		[tarPathRadio selectCellWithTag:PATH_GNUTAR_TAG];
	else if([ctrl_value isEqualToString:TAR_PATH])
		[tarPathRadio selectCellWithTag:PATH_TAR_TAG];
	else
		[tarPathRadio selectCellWithTag:PATH_CUSTOM_TAG];
}


- (void) syncExtension
{
  NSString* ctrl_value = [extensionText stringValue];

  // check for matches with choices
  if([prefsObj compressWithGzip])
    {
      [[extensionRadio cellWithTag:EXT_LONG_TAG] setEnabled:YES];
		
      if([ctrl_value isEqualToString:GZIP_SHORT_EXT])
	{
	  [extensionRadio selectCellWithTag:EXT_SHORT_TAG];
	}
      else if([ctrl_value isEqualToString:GZIP_LONG_EXT])
	{
	  [extensionRadio selectCellWithTag:EXT_LONG_TAG];
	}
      else
	{
	  [extensionRadio selectCellWithTag:EXT_CUSTOM_TAG];
	}
    }
  else if([prefsObj compressWithCompress])
    {
      [[extensionRadio cellWithTag:EXT_LONG_TAG] setEnabled:YES];

      if([ctrl_value isEqualToString:COMPRESS_SHORT_EXT])
	{
	  [extensionRadio selectCellWithTag:EXT_SHORT_TAG];
	}
      else if([ctrl_value isEqualToString:COMPRESS_LONG_EXT])
	{
	  [extensionRadio selectCellWithTag:EXT_LONG_TAG];
	}
      else
	{
	  [extensionRadio selectCellWithTag:EXT_CUSTOM_TAG];
	}
    }
  else if([prefsObj compressWithBzip])
    {
      [[extensionRadio cellWithTag:EXT_LONG_TAG] setEnabled:YES];

      if([ctrl_value isEqualToString:BZIP_SHORT_EXT])
	{
	  [extensionRadio selectCellWithTag:EXT_SHORT_TAG];
	}
      else if([ctrl_value isEqualToString:BZIP_LONG_EXT])
	{
	  [extensionRadio selectCellWithTag:EXT_LONG_TAG];
	}
      else
	{
	  [extensionRadio selectCellWithTag:EXT_CUSTOM_TAG];
	}
    }
  else
    {
      [[extensionRadio cellWithTag:EXT_LONG_TAG] setEnabled:NO];
      if([[extensionRadio selectedCell] tag] == EXT_LONG_TAG)
	[extensionRadio selectCellWithTag:EXT_SHORT_TAG];

      if([ctrl_value isEqualToString:NONE_SHORT_EXT])
	{
	  [extensionRadio selectCellWithTag:EXT_SHORT_TAG];
	}
      else
	{
	  [extensionRadio selectCellWithTag:EXT_CUSTOM_TAG];
	}
    }
}


// NSWindow delegate function
- (void)windowWillClose:(NSNotification *)aNotification
{
	// error check the launch path
	[self errorCheckTarPath];
}


@end
