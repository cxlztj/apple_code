//
//  FreeTar
//  FreeTarPreferences.m
//
//  Copyright (c) 2002 Murray M Johnson
//
//	http://homepage.mac.com/mjsoftware/
//	mjsoftware@mac.com
//
//
//  This file is part of FreeTar version 1.1.
//
//  FreeTar is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  FreeTar is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with FreeTar; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

#import "FreeTarPreferences.h"

NSString* PREFS_LAUNCH_PATH_KEY			= @"Launch Path";
NSString* PREFS_COMPRESS_WITH_GZIP_KEY		= @"Compress With Gzip";
NSString* PREFS_COMPRESS_WITH_COMPRESS_KEY	= @"Compress With Compress";
NSString* PREFS_COMPRESS_WITH_BZIP_KEY	        = @"Compress With Bzip";
NSString* PREFS_ARCHIVE_EXTENSION_KEY		= @"Archive Extension";
NSString* PREFS_AUTO_LOCATION			= @"Automatic Location";
NSString* PREFS_AUTO_BASE_DIR			= @"Automatic Base Directory";
NSString* PREFS_MULTIPLE_ARCHIVES		= @"Multiple Archives";


@implementation FreeTarPreferences


+ (void) initialize
{
  NSMutableDictionary* prefs = [NSMutableDictionary dictionaryWithCapacity:10];

	
  // create dictionary with factory defaults
  //	[prefs setObject:@"/usr/bin/gnutar" forKey:PREFS_LAUNCH_PATH_KEY];
  [prefs setObject:@"/usr/bin/tar" forKey:PREFS_LAUNCH_PATH_KEY];
  [prefs setObject:[NSNumber numberWithBool:YES] forKey:PREFS_COMPRESS_WITH_GZIP_KEY];
  [prefs setObject:[NSNumber numberWithBool:NO] forKey:PREFS_COMPRESS_WITH_COMPRESS_KEY];
  [prefs setObject:[NSNumber numberWithBool:NO] forKey:PREFS_COMPRESS_WITH_BZIP_KEY];
  [prefs setObject:@"tgz" forKey:PREFS_ARCHIVE_EXTENSION_KEY];
  [prefs setObject:[NSNumber numberWithBool:NO] forKey:PREFS_AUTO_LOCATION];
  [prefs setObject:[NSNumber numberWithBool:YES] forKey:PREFS_AUTO_BASE_DIR];
  [prefs setObject:[NSNumber numberWithBool:NO] forKey:PREFS_MULTIPLE_ARCHIVES];

	
  // register factory defaults
  [[NSUserDefaults standardUserDefaults] registerDefaults:prefs];
}


- (void) setLaunchPath:(NSString*)inPath
{
	[[NSUserDefaults standardUserDefaults] setObject:inPath forKey:PREFS_LAUNCH_PATH_KEY];
}


- (NSString*) launchPath
{
	return [[NSUserDefaults standardUserDefaults] objectForKey:PREFS_LAUNCH_PATH_KEY];
}


- (void) setCompressWithGzip:(BOOL)inFlag
{
  [[NSUserDefaults standardUserDefaults] setBool:inFlag forKey:PREFS_COMPRESS_WITH_GZIP_KEY];
}


- (BOOL) compressWithGzip
{
  return [[NSUserDefaults standardUserDefaults] boolForKey:PREFS_COMPRESS_WITH_GZIP_KEY];
}


- (void) setCompressWithCompress:(BOOL)inFlag
{
  [[NSUserDefaults standardUserDefaults] setBool:inFlag forKey:PREFS_COMPRESS_WITH_COMPRESS_KEY];
}


- (BOOL) compressWithCompress
{
  return [[NSUserDefaults standardUserDefaults] boolForKey:PREFS_COMPRESS_WITH_COMPRESS_KEY];
}


- (void) setCompressWithBzip:(BOOL)inFlag
{
  [[NSUserDefaults standardUserDefaults] setBool:inFlag forKey:PREFS_COMPRESS_WITH_BZIP_KEY];
}


- (BOOL) compressWithBzip
{
  return [[NSUserDefaults standardUserDefaults] boolForKey:PREFS_COMPRESS_WITH_BZIP_KEY];
}



- (void) setArchiveExtension:(NSString*)inExt
{
	[[NSUserDefaults standardUserDefaults] setObject:inExt forKey:PREFS_ARCHIVE_EXTENSION_KEY];
}


- (NSString*) archiveExtension
{
	return [[NSUserDefaults standardUserDefaults] objectForKey:PREFS_ARCHIVE_EXTENSION_KEY];
}


- (void) setAutoLocation:(BOOL)inFlag
{
	[[NSUserDefaults standardUserDefaults] setBool:inFlag forKey:PREFS_AUTO_LOCATION];
}


- (BOOL) autoLocation
{
	return [[NSUserDefaults standardUserDefaults] boolForKey:PREFS_AUTO_LOCATION];
}


- (void) setAutoBaseDir:(BOOL)inFlag
{
	[[NSUserDefaults standardUserDefaults] setBool:inFlag forKey:PREFS_AUTO_BASE_DIR];
}


- (BOOL) autoBaseDir
{
	return [[NSUserDefaults standardUserDefaults] boolForKey:PREFS_AUTO_BASE_DIR];
}


- (void) setMultipleArchives:(BOOL)inFlag
{
	[[NSUserDefaults standardUserDefaults] setBool:inFlag forKey:PREFS_MULTIPLE_ARCHIVES];
}


- (BOOL) multipleArchives
{
	return [[NSUserDefaults standardUserDefaults] boolForKey:PREFS_MULTIPLE_ARCHIVES];
}


@end
