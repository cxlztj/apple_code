//
//  FreeTar
//  FreeTarController.h
//
//  Copyright (c) 2002 Murray M Johnson
//
//	http://homepage.mac.com/mjsoftware/
//	mjsoftware@mac.com
//
//
//  This file is part of FreeTar version 1.1.
//
//  FreeTar is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  FreeTar is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with FreeTar; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

#import <AppKit/AppKit.h>

@class FreeTarPreferences;
@class PreferencesController;


// FreeTarController is the main controller object for the FreeTar App. This
// class is instantiated in the "MainMenu.nib" nib file, and connections are
// made between this class and the window, controls, and menu commands.
// In the nib file, this class is also connected as the application delegate
@interface FreeTarController : NSObject
{
  IBOutlet NSWindow*				mainWindow;
  IBOutlet NSTextField*			largeStatusText;
  IBOutlet NSTextField*			smallStatusText;
  IBOutlet NSProgressIndicator*	progressBar;
  IBOutlet NSButton*				cancelButton;

  NSTimer*						timer;
  NSMutableArray*					fileList;
  NSTask*							tarTask;
  NSPipe*							tarStdOut;
  int								filesToArchive;
  int								filesArchived;
  NSString*						archivePath;
  BOOL							archiveFailed;
  BOOL							quitWhenFinished;
  BOOL							appHasLaunched;

  PreferencesController*			preferencesController;
  FreeTarPreferences*				preferences;
}

// NSApplication delegate functions
- (void) applicationDidFinishLaunching:(NSNotification *)aNotification;
- (BOOL) application:(NSApplication *)theApplication openFile:(NSString *)filename;

// NSWindow delegate functions
- (BOOL)windowShouldClose:(id)sender;

// menu commands (actions connected to menu items in nib file)
- (IBAction) newTarArchive:(id)sender;
- (IBAction) preferences:(id)sender;
- (IBAction) cancelButtonPressed:(id)sender;

// GUI Object access
- (void) spinProgressBar;
- (void) setProgressBarValue:(double)value;
- (void) setLargeStatusTextValue:(NSString*)message;
- (void) setSmallStatusTextValue:(NSString*)message;

// tar archive creation
- (void) filesWereDragged:(NSTimer*)aTimer;
- (void) createNewArchiveWithFiles:(NSArray*)theFiles;
- (void) startArchive:(NSString*)fullPath withFiles:(NSArray*)theFiles;
//DLE - (void) monitorTarOperation:(NSTimer*)aTimer;
- (int) countFilesInList:(NSArray*)theFiles;
- (void) dataAvailable:(NSNotification*)aNotification;
- (void) taskDidTerminate:(NSNotification*)aNotification;

// error handling
- (void) doError:(NSString*)message;

@end
