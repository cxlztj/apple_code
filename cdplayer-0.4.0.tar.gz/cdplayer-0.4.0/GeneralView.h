/* vim: set ft=objc ts=4 nowrap: */
/* All Rights reserved */

#ifndef GENERALVIEW_H_INCLUDED
#define GENERALVIEW_H_INCLUDED

#include <AppKit/AppKit.h>

@interface GeneralView : NSObject
{
  id view;
  id window;
  id exitMatrix;
  id deviceField;
}

- (id) init;
- (id) initWithNibName: (NSString *) nibName;

- (void) saveChanges;

- (NSString *) name;
- (NSView *) view;

+ (id) singleInstance;

@end

#endif
