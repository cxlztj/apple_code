/* vim: set ft=objc ts=4 nowrap: */
/*
 *  TrackListView.m
 *
 *  Copyright (c) 2003
 *
 *  Author: Andreas Heppel <aheppel@web.de>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "TrackListView.h"

/* This class is for displaying the drag image.
 */
@interface TrackTable : NSTableView
{
}

- (NSImage *) dragImageForRows: (NSArray *) dragRows
			 event: (NSEvent *) dragEvent 
	       dragImageOffset: (NSPoint *) dragImageOffset;
@end

@implementation TrackTable

- (NSImage *) dragImageForRows: (NSArray *) dragRows
			 event: (NSEvent *) dragEvent 
		   dragImageOffset: (NSPoint *) dragImageOffset
{
	if ([dragRows count] > 1) {
		return [NSImage imageNamed: @"iconDnDAudioMulti.tiff"];
	} else {
		return [NSImage imageNamed: @"iconDnDAudio.tiff"];
	}
}

@end


@implementation TrackListView

- (id) initWithFrame: (NSRect) frameRect
{
	NSTableColumn *column;
	NSRect frame = NSMakeRect(0,0,frameRect.size.width,frameRect.size.height);

	self = [super initWithFrame: frameRect];
	if (self) {
		table = [[TrackTable alloc] initWithFrame: frame];
		[table setAllowsMultipleSelection: YES];
		[table setAllowsEmptySelection: NO];
		[table setAllowsColumnSelection: NO];
		[table setDrawsGrid: YES];
		[table setAllowsColumnResizing: YES];
		[table setAutoresizesAllColumnsToFit: YES];
		// we set the delegate and data source in awakeFromNib!!
		// we don't know them, yet!!

		column = [[NSTableColumn alloc] initWithIdentifier: @"Title"];
		[column setEditable: YES];
		[column setResizable: YES];
		[[column headerCell] setStringValue: _(@"Title")];
		[column setMinWidth: 20];
		[column setMaxWidth: 100000];
		[column setWidth: 220];

		[table addTableColumn: column];
		[column release];

		column = [[NSTableColumn alloc] initWithIdentifier: @"Duration"];
		[column setEditable: NO];
		[column setResizable: NO];
		[[column headerCell] setStringValue: _(@"Duration")];
		[column setMinWidth: 20];
		[column setMaxWidth: 80];
		[column setWidth: 80];
		[[column dataCell] setAlignment: NSCenterTextAlignment];

		[table addTableColumn: column];
		[column release];

		scroll = [[NSScrollView alloc] initWithFrame: frame];
		[scroll setHasHorizontalScroller: NO];
		[scroll setHasVerticalScroller: YES];
		[scroll setDocumentView: table];
		[scroll setBorderType: NSBezelBorder];
		[scroll setAutoresizingMask: NSViewWidthSizable | NSViewHeightSizable];

		[self addSubview: scroll];
	}

	return self;
}

- (void) dealloc
{
	[table release];
	[scroll release];
	[super dealloc];
}

- (void) awakeFromNib
{
	[table setDelegate: delegate];
	[table setDataSource: delegate];
}

- (void) reloadData
{
	[table reloadData];
}

- (void) forwardInvocation: (NSInvocation *)invocation
{
	if ([table respondsToSelector: [invocation selector]])
		[invocation invokeWithTarget: table];
	else
		[self doesNotRecognizeSelector: [invocation selector]];
}

@end
