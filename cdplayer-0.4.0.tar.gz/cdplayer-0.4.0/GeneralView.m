/* All Rights reserved */

#include <AppKit/AppKit.h>
#include "GeneralView.h"


static GeneralView *singleInstance = nil;

@interface GeneralView (Private)

- (void) initializeFromDefaults;

@end


@implementation GeneralView(Private)

- (void) initializeFromDefaults
{
	NSUserDefaults	*defaults = [NSUserDefaults standardUserDefaults];
	NSString	*device;
	int		onExit;

	device = [defaults stringForKey: @"Device"];
	[deviceField setStringValue: device];

	onExit = [defaults integerForKey: @"OnExit"];
	[exitMatrix selectCellAtRow: onExit column: 0];
}

@end


@implementation GeneralView

- (id) init
{
	return [self initWithNibName: @"General"];
}

- (id) initWithNibName: (NSString *) nibName
{
	int i;
	NSBundle *bundle;
	NSString *bundlePath;
	NSArray *searchPaths;

	if (singleInstance) {
		[self dealloc];
	} else {
		self = [super init];

		// We link our view
		if (![NSBundle loadNibNamed: nibName owner: self]) {
			NSLog (@"General: Could not load nib \"%@\".", nibName);
			[self dealloc];
		} else {
			view = [window contentView];
			[view retain];

			// We get our defaults for this panel
			[self initializeFromDefaults];

			singleInstance = self;
		}
	}
	return singleInstance;
}

- (void) dealloc
{
	singleInstance = nil;
	TEST_RELEASE(view);
	[super dealloc];
}

// access methods

- (NSString *) name
{
	return _(@"General");
}

- (NSView *) view
{
	return view;
}

- (void) saveChanges
{
	NSUserDefaults	*defaults = [NSUserDefaults standardUserDefaults];
	NSString *device = [deviceField stringValue];
	[defaults setObject: device?device:@"" forKey: @"Device"];
	[defaults setInteger: [exitMatrix selectedRow] forKey: @"OnExit"];
}


//
// class methods
//
+ (id) singleInstance
{
	if (!singleInstance) {
		singleInstance = [[GeneralView alloc] initWithNibName: @"General"];
	}

	return singleInstance;
}

@end
