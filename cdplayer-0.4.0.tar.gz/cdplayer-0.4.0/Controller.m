#include "Controller.h"
#include "Player.h"
#include "Preferences.h"
#include "TrackList.h"

@implementation Controller


void createMenu()
{
        NSMenu*         menu;
        NSMenu*         info;
        NSMenu*         services;
        SEL             action = @selector(method:);


        ///// Create the app menu /////
        menu = [[NSMenu alloc] initWithTitle: @"CDPlayer"];

        [menu addItemWithTitle: _(@"Info")
                        action: action
                 keyEquivalent: @""];

        [menu addItemWithTitle: _(@"Show Track List")
                        action: @selector(showTrackList:)
                 keyEquivalent: @"l"];

	[menu addItemWithTitle: _(@"Query CDDB")
			action: @selector(queryCddb:)
		 keyEquivalent: @"Q"];

        [menu addItemWithTitle: _(@"Hide")
                        action: @selector(hide:)
                 keyEquivalent: @"h"];

	[menu addItemWithTitle:_(@"Services")
                        action: action
                 keyEquivalent:@""];

	services = AUTORELEASE([NSMenu new]);
	[menu setSubmenu: services
                 forItem: [menu itemWithTitle: _(@"Services")]];

        [menu addItemWithTitle: _(@"Quit")
                        action: @selector(terminate:)
                 keyEquivalent: @"q"];


        ///// Create the info submenu /////
        info = [NSMenu new];
        [menu setSubmenu: info
                 forItem: [menu itemWithTitle: _(@"Info")]];

        [info addItemWithTitle: _(@"Info Panel...")
                        action: @selector(orderFrontStandardInfoPanel:)
                 keyEquivalent: @""];

        [info addItemWithTitle: _(@"Preferences...")
                        action: @selector(showPrefPanel:)
                 keyEquivalent: @""];

        [info addItemWithTitle: _(@"Help")
                        action: @selector(showMyHelp:)
                 keyEquivalent: @"?"];


	[NSApp setServicesMenu: services];
        [[NSApplication sharedApplication] setMainMenu: menu];

        [menu update];
        [menu display];
}

- (void) dealloc
{
	RELEASE(player);
}

- (void)applicationWillFinishLaunching:(NSNotification *)not
{
	createMenu();
}

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
	player = [Player sharedPlayer];
	[NSApp setServicesProvider: player];
	[TrackList sharedTrackList];
}

- (BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication *)theApplication
{
	return NO;
}

- (BOOL)applicationShouldTerminate:(NSApplication *)sender
{
	NSUserDefaults	*defaults = [NSUserDefaults standardUserDefaults];

	switch ([defaults integerForKey: @"OnExit"])
	{
	// auto stop
	case 1 :	[player stop: self];
			break;
	// auto eject
	case 2 :	[player eject: self];
			break;
	// none
	case 0 :
	default:
			break;
	}

	return YES;
}

- (void)showPrefPanel:(id)sender
{
	[[Preferences singleInstance] showPanel: self];
}

- (void)showTrackList:(id)sender
{
	[[TrackList sharedTrackList] activate];
}


- (IBAction)showMyHelp: (id)sender
{
	NSBundle *mb = [NSBundle mainBundle];
	NSString *file = [mb pathForResource: @"CDPlayer" ofType: @"help"]; 
 
	if (file) {
		[[NSWorkspace sharedWorkspace] openFile: file];
		return;
   	}
	NSBeep();
}


@end
