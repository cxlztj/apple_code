/* vim: set ft=objc ts=4 nowrap: */

#include "Preferences.h"
#include "FreeDBView.h"
#include "GeneralView.h"

static	Preferences *pref_panel = nil;

@implementation Preferences

+ (id) singleInstance
{
	if (!pref_panel) {
		pref_panel = [[Preferences alloc] init];
	}
  
	return pref_panel;
}

- (id) init
{
	id		module = nil;
  
	modules = [[NSMutableDictionary alloc] initWithCapacity: 2];
	
	[self layoutWindow];

	// initialise all sub panels
	module = [GeneralView singleInstance];
	if (module)
		[modules setObject: module forKey: [(GeneralView*)module name]];
	[panelList addItemWithTitle: [(GeneralView*)module name]];
	[module release];

	module = [FreeDBView singleInstance];
	if (module)
		[modules setObject: module forKey: [(FreeDBView*)module name]];
	[panelList addItemWithTitle: [(FreeDBView*)module name]];
	[module release];
  
	return self;
}

- (void) dealloc
{
	[window release];
	[panelList release];
	[saveButton release];
	[closeButton release];
	[panelBox release];

	[modules release];
  
	[super dealloc];
}

- (void) windowWillClose: (NSNotification *)theNotification
{
	AUTORELEASE(self);
	pref_panel = nil;
}

- (void) showPanel: (id) sender
{
	[self showSubPanel: self];
	[NSApp runModalForWindow: window];
}

- (void) save: (id) sender
{
	int i;
	id theModules = [modules allValues];

	for (i = 0; i < [theModules count]; i++)
		[[theModules objectAtIndex: i] saveChanges];

	[[NSUserDefaults standardUserDefaults] synchronize];
}

- (void) close: (id) sender
{
	[NSApp stopModal];
	[window performClose: self];
}

- (void) showSubPanel: (id) sender
{
	id module;
	
	module = [modules objectForKey: [panelList titleOfSelectedItem]];

	if (module) {
		if ([panelBox contentView] != [module view]) {
			[panelBox setContentView: [module view]];
			[panelBox setTitle: [(FreeDBView*)module name]];
		}
	} else {
	}
}

- (void) layoutWindow
{
	NSRect frame;
	unsigned int style = NSTitledWindowMask|NSClosableWindowMask|NSMiniaturizableWindowMask;

	frame = NSMakeRect(100, 100, 370,375);
	window = [[NSPanel alloc] initWithContentRect: frame
			    styleMask: style
			    backing: NSBackingStoreRetained
			    defer: NO];
	[window setTitle: _(@"Preferences")];
	[window setMaxSize: frame.size];
	[window setMinSize: frame.size];
  
	frame = NSMakeRect(195, 10, 80, 28);
	saveButton = [[NSButton alloc] initWithFrame: frame];
	[saveButton setButtonType: NSMomentaryPushButton];
	[saveButton setTitle: _(@"Save")];
	[saveButton setTarget: self];
	[saveButton setAction: @selector(save:)];
	[[window contentView] addSubview: saveButton];

	frame = NSMakeRect(285, 10, 80, 28);
	closeButton = [[NSButton alloc] initWithFrame: frame];
	[closeButton setTitle: _(@"Close")];
	[closeButton setTarget: self];
	[closeButton setAction: @selector(close:)];
	[[window contentView] addSubview: closeButton];

	frame = NSMakeRect(135, 315, 100, 25);
	panelList = [[NSPopUpButton alloc] initWithFrame: frame pullsDown: NO];
	[panelList setAutoenablesItems: NO];
	[panelList setEnabled: YES];
	[panelList setTarget: self];
	[panelList setAction: @selector(showSubPanel:)];
	[[window contentView] addSubview: panelList];

	panelBox = [[NSBox alloc] initWithFrame: NSMakeRect(5,45,360,265)];
	[panelBox setTitlePosition: NSAtTop];
	[panelBox setBorderType: NSGrooveBorder];
	[[window contentView] addSubview: panelBox];

	[window center];
}

@end
