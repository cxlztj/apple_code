/* vim: set ft=objc ts=4 nowrap: */
/*
**  AudioCDProtocol.h
**
**  Copyright (c) 2002
**
**  Author: Andreas Heppel <aheppel@web.de>
**
**  This program is free software; you can redistribute it and/or modify
**  it under the terms of the GNU Lesser General Public License as published by
**  the Free Software Foundation; either version 2 of the License, or
**  (at your option) any later version.
**
**  This program is distributed in the hope that it will be useful,
**  but WITHOUT ANY WARRANTY; without even the implied warranty of
**  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**  GNU General Public License for more details.
**
**  You should have received a copy of the GNU Lesser General Public License
**  along with this program; if not, write to the Free Software
**  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef __AUDIOCD_PROTOCOL_H_INCLUDED
#define __AUDIOCD_PROTOCOL_H_INCLUDED

#include <Foundation/Foundation.h>


#define AUDIOCD_PLAYING			0
#define AUDIOCD_PAUSED			1
#define AUDIOCD_COMPLETED		2
#define AUDIOCD_NOSTATUS		3

@protocol CDHandlerProtocol <NSObject>

- (BOOL) audioCD: (id)sender error: (int)no message: (NSString *)msg;
- (void) audioCDChanged: (id)sender;

@end

@protocol AudioCDProtocol <NSObject>

- init;
- initWithPath: (NSString *)device;
- initWithPath: (NSString *)device andHandler: (id<CDHandlerProtocol>)handler;

- (void)setHandler: (id<CDHandlerProtocol>)handler;

- (void) startCheck;
- (void) stopCheck;

- (NSString *) device;

- (NSMutableDictionary *)readTOC;

- (void)playStart: (int)start End: (int)end;
- (void)playStart: (int)start End: (int)end Pos: (int)pos;
- (void)pause;
- (void)resume;
- (void)stop;
- (void)eject;
- (void)close;

- (void)reset;

- (BOOL)cdPresent;
- (BOOL)checkForCDWithId: (NSString *)cddbId;

- (int)currentState;
- (int)currentTrack;
- (int)currentMin;
- (int)currentSec;
- (int)firstTrack;
- (int)totalTrack;
- (int)trackLength:(int)track;

@end

#endif
